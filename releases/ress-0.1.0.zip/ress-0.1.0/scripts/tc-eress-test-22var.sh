../bin/eress --input_file:systems/cstr_22comp.txt --tc --n_results:132 --output_file:results/output-tc-eress-22var.txt --hs_input_file:hsfiles/hsfile-22.txt --verbose
