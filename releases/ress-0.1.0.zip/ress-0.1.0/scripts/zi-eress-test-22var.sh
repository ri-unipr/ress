../bin/eress --input_file:systems/cstr_22comp.txt --zi --n_results:132 --output_file:results/output-zi-eress-22var.txt --verbose
