../bin/eress --input_file:systems/cstr_28.txt --zi --n_results:136 --output_file:results/output-zi-eress-28var.txt --verbose
