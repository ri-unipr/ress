../bin/eress --input_file:systems/cstr_21.txt --zi --n_results:132 --output_file:results/output-zi-eress-21var.txt --verbose
