# Relevance Index (RI)

Results are placed into this folder.
