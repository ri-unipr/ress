../bin/homgen --input_file:systems/cstr_22comp.txt --hs_output_file:hsfiles/hsfile-22.txt
