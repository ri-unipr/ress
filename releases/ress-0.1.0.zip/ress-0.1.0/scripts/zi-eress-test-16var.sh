../bin/eress --input_file:systems/CSTR16_00.txt --zi --n_results:100 --output_file:results/output-zi-eress-16var.txt --verbose
