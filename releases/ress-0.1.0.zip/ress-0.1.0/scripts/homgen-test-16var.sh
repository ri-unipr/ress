../bin/homgen --input_file:systems/CSTR16_00.txt --hs_output_file:hsfiles/hsfile-16.txt
