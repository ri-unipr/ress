../bin/homgen --input_file:systems/cstr_28.txt --hs_output_file:hsfiles/hsfile-28.txt
