../bin/eress --input_file:systems/cstr_21.txt --tc --n_results:132 --output_file:results/output-tc-eress-21var.txt --hs_input_file:hsfiles/hsfile-21.txt --verbose
