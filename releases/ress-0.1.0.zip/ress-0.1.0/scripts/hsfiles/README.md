# Relevance Index (RI)

Homogeneous System files are placed into this folder.
