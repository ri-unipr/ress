../bin/eress --tc --input_file:systems/CSTR16_00.txt --n_results:132 --output_file:results/output-tc-eress-16var.txt --hs_input_file:hsfiles/hsfile-16.txt --verbose
