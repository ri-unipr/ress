../bin/homgen --input_file:systems/cstr_21.txt --hs_output_file:hsfiles/hsfile-21.txt
