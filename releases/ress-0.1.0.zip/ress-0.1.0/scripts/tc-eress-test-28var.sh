../bin/eress --input_file:systems/cstr_28.txt --tc --n_results:132 --output_file:results/output-tc-eress-28var.txt --hs_input_file:hsfiles/hsfile-28.txt --verbose
