# Relevance Index (RI)

Variables are placed into this folder.
